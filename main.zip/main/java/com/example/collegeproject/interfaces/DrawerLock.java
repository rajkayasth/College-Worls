package com.example.collegeproject.interfaces;

public interface DrawerLock {
    public void setDrawerLocked(boolean sh);
}
