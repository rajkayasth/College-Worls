package com.example.collegeproject.module;

public class FacultyModule {
    public String f_name;
    public String f_email;
    public String f_department;
    public String f_degree;
}
