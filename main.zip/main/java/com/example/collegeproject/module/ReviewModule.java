package com.example.collegeproject.module;

public class ReviewModule {
    public String name;
    public String profile;
    public String description;
    public Float ratting;
    public String rdate;
}
