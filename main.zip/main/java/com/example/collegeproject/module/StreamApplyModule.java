package com.example.collegeproject.module;

public class StreamApplyModule {
    public String s_name;
}
