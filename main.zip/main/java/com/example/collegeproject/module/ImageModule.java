package com.example.collegeproject.module;

public class ImageModule {
    public String profile;

    public ImageModule(String profile) {
        this.profile = profile;
    }

    public String getProfile() {
        return profile;
    }
}
