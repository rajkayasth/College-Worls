package com.example.collegeproject.module;

public class WishListModule {
    public String clg_name;
    public String profile;

}
