package com.example.collegeproject.module;

public class PlacementModule {
    public String p_name;
    public String p_com_desc;
    public String p_com_ratting;
    public String profile;
}
