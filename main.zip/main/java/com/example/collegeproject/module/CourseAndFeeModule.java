package com.example.collegeproject.module;

public class CourseAndFeeModule {
    public String co_id;
    public String co_name;
    public String fees;
}
